import React from 'react'

export default function DetailedCuisin(props) {
    return (
        <div>
            {
               props.selectedCuisine
            }
        </div>
    )
}
