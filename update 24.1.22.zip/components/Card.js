import { Box } from '@mui/system'
import React from 'react'

export default function Card() {
    return (
        <Box sx={{width: '300px', height: '100px', background: '#cfcfcf', borderRadius: '30px'}}>
            Box 1
        </Box>
    )
}
